"""
Unit tests for data loader and feature engineering modules.

Tests cover:
- CSV and Parquet file loading
- OHLCV data resampling
- Technical indicator calculations (RSI, MACD, ATR, z-score)
- Edge cases and error handling
"""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
import tempfile
import os
import sys

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.loader import DataLoader
from src.data.feature_engineer import FeatureEngineer


class TestDataLoader:
    """Test cases for DataLoader class."""
    
    @pytest.fixture
    def sample_ohlcv_data(self):
        """Create sample OHLCV data for testing."""
        dates = pd.date_range(start='2023-01-01', end='2023-01-10', freq='1H')
        data = {
            'open': np.random.uniform(100, 110, len(dates)),
            'high': np.random.uniform(110, 120, len(dates)),
            'low': np.random.uniform(90, 100, len(dates)),
            'close': np.random.uniform(100, 110, len(dates)),
            'volume': np.random.uniform(1000, 5000, len(dates))
        }
        df = pd.DataFrame(data, index=dates)
        # Ensure high is highest and low is lowest
        df['high'] = df[['open', 'high', 'close']].max(axis=1)
        df['low'] = df[['open', 'low', 'close']].min(axis=1)
        return df
    
    @pytest.fixture
    def data_loader(self):
        """Create DataLoader instance."""
        return DataLoader()
    
    def test_load_csv(self, data_loader, sample_ohlcv_data):
        """Test loading data from CSV file."""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            # Reset index to create datetime column
            df_with_datetime = sample_ohlcv_data.reset_index()
            df_with_datetime.rename(columns={'index': 'datetime'}, inplace=True)
            df_with_datetime.to_csv(f.name, index=False)
            
            # Load the CSV
            loaded_df = data_loader.load_csv(f.name)
            
            # Verify data
            assert isinstance(loaded_df.index, pd.DatetimeIndex)
            assert len(loaded_df) == len(sample_ohlcv_data)
            assert all(col in loaded_df.columns for col in ['open', 'high', 'low', 'close', 'volume'])
            
            # Clean up
            os.unlink(f.name)
    
    def test_load_parquet(self, data_loader, sample_ohlcv_data):
        """Test loading data from Parquet file."""
        with tempfile.NamedTemporaryFile(suffix='.parquet', delete=False) as f:
            sample_ohlcv_data.to_parquet(f.name)
            
            # Load the Parquet file
            loaded_df = data_loader.load_parquet(f.name)
            
            # Verify data
            assert isinstance(loaded_df.index, pd.DatetimeIndex)
            assert len(loaded_df) == len(sample_ohlcv_data)
            assert all(col in loaded_df.columns for col in ['open', 'high', 'low', 'close', 'volume'])
            
            # Clean up
            os.unlink(f.name)
    
    def test_load_nonexistent_file(self, data_loader):
        """Test loading non-existent file raises appropriate error."""
        with pytest.raises(FileNotFoundError):
            data_loader.load_csv('nonexistent_file.csv')
        
        with pytest.raises(FileNotFoundError):
            data_loader.load_parquet('nonexistent_file.parquet')
    
    def test_validate_missing_columns(self, data_loader):
        """Test validation fails when required columns are missing."""
        # Create data missing volume column
        dates = pd.date_range(start='2023-01-01', end='2023-01-10', freq='1H')
        incomplete_data = pd.DataFrame({
            'open': np.random.uniform(100, 110, len(dates)),
            'high': np.random.uniform(110, 120, len(dates)),
            'low': np.random.uniform(90, 100, len(dates)),
            'close': np.random.uniform(100, 110, len(dates))
        }, index=dates)
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            incomplete_data.to_csv(f.name)
            
            with pytest.raises(ValueError, match="Missing required OHLCV columns"):
                data_loader.load_csv(f.name, datetime_col='index')
            
            os.unlink(f.name)
    
    def test_resample_ohlcv(self, data_loader, sample_ohlcv_data):
        """Test OHLCV resampling to different timeframes."""
        # Test resampling to daily
        daily_df = data_loader.resample_ohlcv(sample_ohlcv_data, '1D')
        
        assert len(daily_df) <= len(sample_ohlcv_data) / 24
        assert daily_df['volume'].sum() <= sample_ohlcv_data['volume'].sum() * 1.01  # Allow small float precision difference
        
        # Test resampling to 4H
        four_hour_df = data_loader.resample_ohlcv(sample_ohlcv_data, '4H')
        
        assert len(four_hour_df) <= len(sample_ohlcv_data) / 4
        
        # Verify aggregation rules
        # High should be max of period
        assert all(four_hour_df['high'] >= four_hour_df['open'])
        assert all(four_hour_df['high'] >= four_hour_df['close'])
        # Low should be min of period
        assert all(four_hour_df['low'] <= four_hour_df['open'])
        assert all(four_hour_df['low'] <= four_hour_df['close'])
    
    def test_unsupported_timeframe(self, data_loader, sample_ohlcv_data):
        """Test that unsupported timeframe raises error."""
        with pytest.raises(ValueError, match="Unsupported timeframe"):
            data_loader.resample_ohlcv(sample_ohlcv_data, '2H')  # Not in config
    
    def test_load_and_resample(self, data_loader, sample_ohlcv_data):
        """Test combined load and resample functionality."""
        with tempfile.NamedTemporaryFile(suffix='.parquet', delete=False) as f:
            sample_ohlcv_data.to_parquet(f.name)
            
            # Load and resample to daily
            daily_df = data_loader.load_and_resample(f.name, timeframe='1D')
            
            assert isinstance(daily_df.index, pd.DatetimeIndex)
            assert len(daily_df) <= len(sample_ohlcv_data) / 24
            
            os.unlink(f.name)


class TestFeatureEngineer:
    """Test cases for FeatureEngineer class."""
    
    @pytest.fixture
    def sample_ohlcv_data(self):
        """Create sample OHLCV data for testing."""
        dates = pd.date_range(start='2023-01-01', end='2023-03-01', freq='1D')
        np.random.seed(42)  # For reproducible tests
        
        # Generate realistic price data
        close_prices = 100 + np.cumsum(np.random.randn(len(dates)) * 2)
        
        data = {
            'open': close_prices + np.random.uniform(-1, 1, len(dates)),
            'high': close_prices + np.random.uniform(0, 3, len(dates)),
            'low': close_prices - np.random.uniform(0, 3, len(dates)),
            'close': close_prices,
            'volume': np.random.uniform(100000, 500000, len(dates))
        }
        
        return pd.DataFrame(data, index=dates)
    
    @pytest.fixture
    def feature_engineer(self):
        """Create FeatureEngineer instance."""
        return FeatureEngineer()
    
    def test_compute_rsi(self, feature_engineer, sample_ohlcv_data):
        """Test RSI calculation."""
        rsi = feature_engineer.compute_rsi(sample_ohlcv_data)
        
        # RSI should be between 0 and 100
        assert rsi.min() >= 0
        assert rsi.max() <= 100
        
        # Check for NaN values (expected for first n periods)
        assert rsi.notna().sum() > 0
        
        # Test with custom period
        rsi_10 = feature_engineer.compute_rsi(sample_ohlcv_data, period=10)
        assert len(rsi_10) == len(sample_ohlcv_data)
    
    def test_compute_macd(self, feature_engineer, sample_ohlcv_data):
        """Test MACD calculation."""
        macd_df = feature_engineer.compute_macd(sample_ohlcv_data)
        
        # Check all components are present
        assert 'macd' in macd_df.columns
        assert 'macd_signal' in macd_df.columns
        assert 'macd_diff' in macd_df.columns
        
        # Check lengths match
        assert len(macd_df) == len(sample_ohlcv_data)
        
        # MACD diff should be MACD - Signal
        valid_idx = macd_df.notna().all(axis=1)
        np.testing.assert_array_almost_equal(
            macd_df.loc[valid_idx, 'macd_diff'],
            macd_df.loc[valid_idx, 'macd'] - macd_df.loc[valid_idx, 'macd_signal']
        )
    
    def test_compute_atr(self, feature_engineer, sample_ohlcv_data):
        """Test ATR calculation."""
        atr = feature_engineer.compute_atr(sample_ohlcv_data)
        
        # ATR should be positive
        assert (atr[atr.notna()] > 0).all()
        
        # Check length
        assert len(atr) == len(sample_ohlcv_data)
        
        # Test with custom period
        atr_20 = feature_engineer.compute_atr(sample_ohlcv_data, period=20)
        assert len(atr_20) == len(sample_ohlcv_data)
    
    def test_compute_zscore(self, feature_engineer, sample_ohlcv_data):
        """Test z-score calculation."""
        zscore = feature_engineer.compute_zscore(sample_ohlcv_data)
        
        # Check length
        assert len(zscore) == len(sample_ohlcv_data)
        
        # Z-score should have mean ~0 and std ~1 for valid values
        valid_zscore = zscore[zscore.notna()]
        assert abs(valid_zscore.mean()) < 0.5  # Should be close to 0
        assert 0.5 < valid_zscore.std() < 1.5  # Should be close to 1
    
    def test_compute_all_indicators(self, feature_engineer, sample_ohlcv_data):
        """Test computing all indicators at once."""
        result = feature_engineer.compute_all_indicators(sample_ohlcv_data)
        
        # Check all indicators are present
        expected_indicators = ['rsi', 'macd', 'macd_signal', 'macd_diff', 'atr', 'zscore']
        for indicator in expected_indicators:
            assert indicator in result.columns
        
        # Check original columns are preserved
        for col in sample_ohlcv_data.columns:
            assert col in result.columns
        
        # Check length is preserved
        assert len(result) == len(sample_ohlcv_data)
    
    def test_add_price_features(self, feature_engineer, sample_ohlcv_data):
        """Test additional price feature calculation."""
        result = feature_engineer.add_price_features(sample_ohlcv_data)
        
        # Check new features are present
        expected_features = [
            'price_range', 'price_position', 'returns', 'log_returns',
            'vwap', 'bb_upper', 'bb_middle', 'bb_lower', 'bb_width', 'bb_percent'
        ]
        for feature in expected_features:
            assert feature in result.columns
        
        # Validate price range
        assert (result['price_range'] >= 0).all()
        
        # Validate price position is between 0 and 1
        valid_pos = result['price_position'][result['price_position'].notna()]
        assert (valid_pos >= 0).all() and (valid_pos <= 1).all()
        
        # Validate returns calculation
        expected_returns = sample_ohlcv_data['close'].pct_change()
        pd.testing.assert_series_equal(result['returns'], expected_returns)
    
    def test_case_insensitive_columns(self, feature_engineer):
        """Test that column names are handled case-insensitively."""
        # Create data with uppercase column names
        dates = pd.date_range(start='2023-01-01', end='2023-01-10', freq='1D')
        data = {
            'OPEN': np.random.uniform(100, 110, len(dates)),
            'HIGH': np.random.uniform(110, 120, len(dates)),
            'LOW': np.random.uniform(90, 100, len(dates)),
            'CLOSE': np.random.uniform(100, 110, len(dates)),
            'VOLUME': np.random.uniform(1000, 5000, len(dates))
        }
        df = pd.DataFrame(data, index=dates)
        
        # Should work with uppercase columns
        rsi = feature_engineer.compute_rsi(df)
        assert len(rsi) == len(df)
        
        atr = feature_engineer.compute_atr(df)
        assert len(atr) == len(df)
    
    def test_missing_column_error(self, feature_engineer):
        """Test that missing columns raise appropriate errors."""
        # Create data missing required columns
        dates = pd.date_range(start='2023-01-01', end='2023-01-10', freq='1D')
        incomplete_data = pd.DataFrame({
            'open': np.random.uniform(100, 110, len(dates)),
            'close': np.random.uniform(100, 110, len(dates))
        }, index=dates)
        
        # Should raise error for missing high/low columns
        with pytest.raises(ValueError, match="Column"):
            feature_engineer.compute_atr(incomplete_data)