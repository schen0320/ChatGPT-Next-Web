"""
Unit tests for trading environment and reward calculation.

Tests cover:
- Environment initialization and reset
- Action execution and state transitions
- Reward calculation with various components
- Transaction cost calculations
- Episode termination conditions
"""

import pytest
import numpy as np
import pandas as pd
from pathlib import Path
import sys
import tempfile
import yaml

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.envs.trading_env import TradingEnvironment, create_trading_env
from src.envs.reward import RewardCalculator


class TestRewardCalculator:
    """Test cases for RewardCalculator class."""
    
    @pytest.fixture
    def reward_calculator(self):
        """Create RewardCalculator instance."""
        return RewardCalculator()
    
    @pytest.fixture
    def sample_config(self):
        """Create sample configuration for testing."""
        return {
            'environment': {
                'costs': {
                    'slippage': 0.001,
                    'commission': 0.0005,
                    'spread': 0.0001
                },
                'trading': {
                    'max_position_size': 1.0
                }
            },
            'reward': {
                'weights': {
                    'pnl': 1.0,
                    'transaction_cost': -1.0,
                    'drawdown_penalty': -0.5,
                    'discipline_bonus': 0.1
                },
                'drawdown': {
                    'max_allowed': 0.1,
                    'penalty_scale': 2.0
                },
                'discipline': {
                    'min_hold_periods': 5,
                    'overtrading_threshold': 10,
                    'position_limit_bonus': 0.05
                }
            }
        }
    
    def test_transaction_cost_calculation(self, reward_calculator):
        """Test transaction cost calculation."""
        # Test buy trade
        trade_value = 10000
        trade_size = 0.5
        cost = reward_calculator.calculate_transaction_cost(trade_value, trade_size)
        
        # Expected: slippage (0.1%) + commission (0.05%) + half spread (0.005%)
        expected_cost = 10000 * (0.001 + 0.0005 + 0.00005)
        assert abs(cost - expected_cost) < 0.01
        
        # Test sell trade (negative size)
        cost_sell = reward_calculator.calculate_transaction_cost(trade_value, -trade_size)
        assert cost_sell == cost  # Cost should be same for buy and sell
        
        # Test no trade
        cost_zero = reward_calculator.calculate_transaction_cost(0, 0)
        assert cost_zero == 0
    
    def test_reward_calculation_profit(self, reward_calculator):
        """Test reward calculation with profit."""
        pnl = 100
        transaction_cost = 5
        current_equity = 101000
        
        reward, components = reward_calculator.calculate_reward(
            pnl=pnl,
            transaction_cost=transaction_cost,
            current_equity=current_equity,
            position=0.5,
            step=10,
            action_taken=True
        )
        
        # Check components
        assert components['pnl'] == 100  # 100 * 1.0
        assert components['transaction_cost'] == -5  # 5 * -1.0
        assert components['drawdown'] == 0  # No drawdown
        assert 'discipline' in components
    
    def test_reward_calculation_loss(self, reward_calculator):
        """Test reward calculation with loss."""
        pnl = -50
        transaction_cost = 5
        current_equity = 99000
        
        reward, components = reward_calculator.calculate_reward(
            pnl=pnl,
            transaction_cost=transaction_cost,
            current_equity=current_equity,
            position=-0.5,
            step=20,
            action_taken=True
        )
        
        assert components['pnl'] == -50
        assert components['transaction_cost'] == -5
        assert reward < 0  # Total reward should be negative
    
    def test_drawdown_penalty(self, reward_calculator):
        """Test drawdown penalty calculation."""
        # Set high water mark
        reward_calculator.high_water_mark = 110000
        
        # Test with drawdown below threshold (no penalty)
        current_equity = 105000  # 4.5% drawdown
        _, components = reward_calculator.calculate_reward(
            pnl=0, transaction_cost=0, current_equity=current_equity,
            position=0, step=30, action_taken=False
        )
        assert components['drawdown'] == 0
        
        # Test with drawdown above threshold (penalty applied)
        current_equity = 95000  # 13.6% drawdown
        _, components = reward_calculator.calculate_reward(
            pnl=0, transaction_cost=0, current_equity=current_equity,
            position=0, step=31, action_taken=False
        )
        assert components['drawdown'] < 0  # Should have penalty
    
    def test_discipline_bonus(self, reward_calculator):
        """Test discipline bonus calculation."""
        # Simulate holding position for required periods
        for i in range(10):
            reward_calculator.position_history.append(0.5)
        
        _, components = reward_calculator.calculate_reward(
            pnl=0, transaction_cost=0, current_equity=100000,
            position=0.5, step=40, action_taken=False
        )
        
        # Should get bonus for holding position
        assert components['discipline'] > 0
    
    def test_overtrading_penalty(self, reward_calculator):
        """Test overtrading penalty."""
        # Simulate many trades
        for i in range(15):
            reward_calculator.trade_history.append(100 + i * 5)
        
        _, components = reward_calculator.calculate_reward(
            pnl=0, transaction_cost=0, current_equity=100000,
            position=0, step=180, action_taken=True
        )
        
        # Should have reduced discipline bonus or penalty
        assert components['discipline'] <= 0
    
    def test_reset(self, reward_calculator):
        """Test resetting calculator state."""
        # Add some history
        reward_calculator.trade_history = [1, 2, 3]
        reward_calculator.position_history = [0.5, 0.5, 0.5]
        reward_calculator.high_water_mark = 110000
        
        # Reset
        reward_calculator.reset()
        
        assert len(reward_calculator.trade_history) == 0
        assert len(reward_calculator.position_history) == 0
        assert reward_calculator.high_water_mark == 0


class TestTradingEnvironment:
    """Test cases for TradingEnvironment class."""
    
    @pytest.fixture
    def sample_data(self):
        """Create sample OHLCV data with features for testing."""
        dates = pd.date_range(start='2023-01-01', end='2023-06-01', freq='1h')
        np.random.seed(42)
        
        # Generate price data
        n = len(dates)
        close_prices = 100 + np.cumsum(np.random.randn(n) * 0.5)
        
        data = pd.DataFrame({
            'open': close_prices + np.random.uniform(-0.5, 0.5, n),
            'high': close_prices + np.random.uniform(0, 1, n),
            'low': close_prices - np.random.uniform(0, 1, n),
            'close': close_prices,
            'volume': np.random.uniform(100000, 500000, n),
            'returns': np.concatenate([[0], np.diff(close_prices) / close_prices[:-1]]),
            'rsi': 50 + np.random.uniform(-20, 20, n),
            'macd': np.random.uniform(-1, 1, n),
            'macd_signal': np.random.uniform(-1, 1, n),
            'atr': np.random.uniform(0.5, 2, n),
            'bb_upper': close_prices + 2,
            'bb_middle': close_prices,
            'bb_lower': close_prices - 2
        }, index=dates)
        
        return data
    
    @pytest.fixture
    def trading_env(self, sample_data):
        """Create TradingEnvironment instance."""
        return TradingEnvironment(sample_data)
    
    def test_environment_initialization(self, trading_env):
        """Test environment initialization."""
        assert trading_env.action_space.n == 7
        assert trading_env.observation_space.shape == (50, 16)  # 13 features + 3 state features
        assert trading_env.initial_capital == 100000
    
    def test_reset(self, trading_env):
        """Test environment reset."""
        obs, info = trading_env.reset()
        
        assert obs.shape == (50, 16)
        assert trading_env.position == 0
        assert trading_env.cash == trading_env.initial_capital
        assert trading_env.current_step == 0
        assert 'step' in info
        assert 'equity' in info
    
    def test_step_hold_action(self, trading_env):
        """Test step with hold action."""
        trading_env.reset()
        
        # Take hold action (action 3)
        obs, reward, terminated, truncated, info = trading_env.step(3)
        
        assert obs.shape == (50, 16)
        assert trading_env.position == 0  # No position change
        assert not info['trade_executed']
        assert trading_env.current_step == 1
    
    def test_step_buy_action(self, trading_env):
        """Test step with buy action."""
        trading_env.reset()
        
        # Take buy action (action 5)
        obs, reward, terminated, truncated, info = trading_env.step(5)
        
        assert trading_env.position == 0.5  # Buy position
        assert info['trade_executed']
        assert trading_env.cash < trading_env.initial_capital  # Cash reduced
        assert 'reward_components' in info
    
    def test_step_sell_action(self, trading_env):
        """Test step with sell action."""
        trading_env.reset()
        
        # First buy
        trading_env.step(5)
        
        # Then sell
        obs, reward, terminated, truncated, info = trading_env.step(1)
        
        assert trading_env.position == -0.5  # Sell position
        assert info['trade_executed']
    
    def test_strong_actions(self, trading_env):
        """Test strong buy/sell actions."""
        trading_env.reset()
        
        # Strong buy (action 6)
        obs, reward, terminated, truncated, info = trading_env.step(6)
        assert trading_env.position == 1.0  # Max position
        
        # Strong sell (action 0)
        obs, reward, terminated, truncated, info = trading_env.step(0)
        assert trading_env.position == -1.0  # Max short position
    
    def test_episode_termination_max_steps(self, trading_env):
        """Test episode termination at max steps."""
        trading_env.reset()
        
        terminated = False
        truncated = False
        steps = 0
        
        # Run until truncated
        while not truncated and steps < 1100:
            obs, reward, terminated, truncated, info = trading_env.step(3)  # Hold
            steps += 1
        
        assert truncated
        assert steps == 1000  # Max steps from config
    
    def test_episode_termination_low_equity(self, trading_env):
        """Test episode termination on low equity."""
        trading_env.reset()
        
        # Simulate large loss by manipulating equity and cash
        trading_env.equity = 40000  # Below 50% threshold
        trading_env.cash = 40000  # Also update cash
        
        # The termination check happens in _is_terminated
        assert trading_env._is_terminated()
    
    def test_observation_structure(self, trading_env):
        """Test observation structure and values."""
        obs, _ = trading_env.reset()
        
        # Check observation shape
        assert obs.shape == (50, 16)
        
        # Check no NaN values
        assert not np.isnan(obs).any()
        
        # Check observation is float32
        assert obs.dtype == np.float32
    
    def test_render(self, trading_env, capsys):
        """Test render method."""
        trading_env.render_mode = "human"
        trading_env.reset()
        trading_env.render()
        
        captured = capsys.readouterr()
        assert "Step:" in captured.out
        assert "Position:" in captured.out
        assert "Equity:" in captured.out
    
    def test_episode_summary(self, trading_env):
        """Test episode summary generation."""
        trading_env.reset()
        
        # Execute some trades
        trading_env.step(5)  # Buy
        trading_env.step(3)  # Hold
        trading_env.step(1)  # Sell
        
        summary = trading_env.get_episode_summary()
        
        assert 'total_trades' in summary
        assert 'final_equity' in summary
        assert 'total_return' in summary
        assert summary['total_trades'] >= 2  # At least buy and sell
    
    def test_create_trading_env(self):
        """Test create_trading_env helper function."""
        # Create larger dataset for this test
        # Need at least 1050 days of data after resampling to daily
        dates = pd.date_range(start='2020-01-01', end='2023-12-31', freq='1h')
        n = len(dates)
        np.random.seed(42)
        close_prices = 100 + np.cumsum(np.random.randn(n) * 0.5)
        
        large_data = pd.DataFrame({
            'open': close_prices + np.random.uniform(-0.5, 0.5, n),
            'high': close_prices + np.random.uniform(0, 1, n),
            'low': close_prices - np.random.uniform(0, 1, n),
            'close': close_prices,
            'volume': np.random.uniform(100000, 500000, n)
        }, index=dates)
        
        # Save sample data to temporary file
        with tempfile.NamedTemporaryFile(suffix='.parquet', delete=False) as f:
            large_data.to_parquet(f.name)
            
            # Create environment
            env = create_trading_env(f.name, timeframe='1D')
            
            assert isinstance(env, TradingEnvironment)
            assert env.action_space.n == 7
            
            # Clean up
            Path(f.name).unlink()
    
    def test_invalid_data(self):
        """Test environment with invalid data."""
        # Data missing required features
        bad_data = pd.DataFrame({
            'open': [100, 101, 102],
            'close': [101, 102, 103]
        })
        
        with pytest.raises(ValueError, match="missing required features"):
            TradingEnvironment(bad_data)
    
    def test_insufficient_data(self, sample_data):
        """Test environment with insufficient data."""
        # Too few rows
        small_data = sample_data.iloc[:10]
        
        with pytest.raises(ValueError, match="need at least"):
            TradingEnvironment(small_data)


class TestIntegration:
    """Integration tests for environment and reward system."""
    
    @pytest.fixture
    def setup_env_with_config(self, tmp_path):
        """Set up environment with custom config."""
        # Create custom config
        config = {
            'environment': {
                'episode': {
                    'max_steps': 100,
                    'lookback_window': 10
                },
                'trading': {
                    'initial_capital': 10000,
                    'max_position_size': 1.0,
                    'min_trade_size': 0.1
                },
                'costs': {
                    'slippage': 0.002,
                    'commission': 0.001,
                    'spread': 0.0002
                },
                'actions': {
                    0: 'strong_sell',
                    1: 'sell',
                    2: 'weak_sell',
                    3: 'hold',
                    4: 'weak_buy',
                    5: 'buy',
                    6: 'strong_buy'
                },
                'action_position_sizes': {
                    'strong_sell': -1.0,
                    'sell': -0.5,
                    'weak_sell': -0.25,
                    'hold': 0.0,
                    'weak_buy': 0.25,
                    'buy': 0.5,
                    'strong_buy': 1.0
                },
                'observation': {
                    'features': ['open', 'high', 'low', 'close', 'volume', 'returns'],
                    'state_features': ['position', 'pnl', 'cash']
                }
            },
            'reward': {
                'weights': {
                    'pnl': 1.0,
                    'transaction_cost': -2.0,
                    'drawdown_penalty': -1.0,
                    'discipline_bonus': 0.2
                },
                'drawdown': {
                    'max_allowed': 0.05,
                    'penalty_scale': 3.0
                },
                'discipline': {
                    'min_hold_periods': 3,
                    'overtrading_threshold': 5,
                    'position_limit_bonus': 0.1
                }
            }
        }
        
        config_path = tmp_path / 'test_config.yaml'
        with open(config_path, 'w') as f:
            yaml.dump(config, f)
        
        # Create data
        dates = pd.date_range(start='2023-01-01', end='2023-02-01', freq='1h')
        n = len(dates)
        close_prices = 100 + np.cumsum(np.random.randn(n) * 0.3)
        
        data = pd.DataFrame({
            'open': close_prices + np.random.uniform(-0.2, 0.2, n),
            'high': close_prices + np.random.uniform(0, 0.5, n),
            'low': close_prices - np.random.uniform(0, 0.5, n),
            'close': close_prices,
            'volume': np.random.uniform(100000, 200000, n),
            'returns': np.concatenate([[0], np.diff(close_prices) / close_prices[:-1]])
        }, index=dates)
        
        env = TradingEnvironment(data, str(config_path))
        
        return env, config_path
    
    def test_full_episode_run(self, setup_env_with_config):
        """Test running a full episode with various actions."""
        env, _ = setup_env_with_config
        
        obs, info = env.reset()
        done = False
        total_reward = 0
        actions_taken = []
        
        # Run episode with predefined action sequence
        action_sequence = [3, 3, 4, 5, 3, 3, 3, 1, 0, 3, 3, 6, 3, 3, 2]
        
        for i in range(min(len(action_sequence), 100)):
            action = action_sequence[i % len(action_sequence)]
            obs, reward, terminated, truncated, info = env.step(action)
            
            total_reward += reward
            actions_taken.append(action)
            
            if terminated or truncated:
                done = True
                break
        
        # Get episode summary
        summary = env.get_episode_summary()
        
        # Verify episode completed
        assert len(actions_taken) > 0
        assert 'total_trades' in summary
        assert 'final_equity' in summary
        
        # Check that trades were executed
        assert summary['total_trades'] > 0
    
    def test_reward_consistency(self, setup_env_with_config):
        """Test that rewards are calculated consistently."""
        env, _ = setup_env_with_config
        env.reset()
        
        # Execute a buy trade
        _, reward1, _, _, info1 = env.step(5)  # Buy
        
        # Reset and repeat
        env.reset()
        _, reward2, _, _, info2 = env.step(5)  # Buy
        
        # Rewards should be similar (not exactly same due to different starting points)
        # Transaction costs can vary based on price, so allow reasonable variance
        assert abs(reward1 - reward2) < 100  # Allow variance due to price differences