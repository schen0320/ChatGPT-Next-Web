# Task 3 Implementation Assumptions

This document outlines the assumptions made during the implementation of Task 3 - Environment and Reward.

## Trading Environment Assumptions

### 1. **Episode Structure**
- Episodes have a maximum of 1000 steps (configurable)
- Lookback window of 50 bars for observations
- Episode starts at a random point in historical data
- Episode terminates if equity drops below 50% of initial capital

### 2. **Action Space**
- 7 discrete actions mapping to different position sizes:
  - 0: Strong Sell (-100% position)
  - 1: Sell (-50% position)
  - 2: Weak Sell (-25% position)
  - 3: Hold (0% position change)
  - 4: Weak Buy (+25% position)
  - 5: Buy (+50% position)  
  - 6: Strong Buy (+100% position)

### 3. **Position Management**
- Positions are expressed as fractions of maximum position size
- Maximum position size is 100% of initial capital
- Minimum trade size is 1% of maximum position to avoid excessive small trades
- Position changes below minimum threshold are ignored

### 4. **Transaction Costs**
- Slippage: 0.1% of trade value
- Commission: 0.05% per trade
- Spread: 0.01% (half paid on entry, half on exit)
- All costs are deducted from available cash

### 5. **Observation Space**
- Stacked observations of shape (lookback_window, n_features)
- Market features: OHLCV, returns, technical indicators (RSI, MACD, ATR, Bollinger Bands)
- State features: current position, unrealized PnL, normalized cash
- All observations are float32 for compatibility with neural networks

## Reward Function Assumptions

### 1. **Reward Components**
- **PnL**: Weight 1.0 - Direct profit/loss from trades
- **Transaction Costs**: Weight -1.0 - Penalty for trading costs
- **Drawdown Penalty**: Weight -0.5 - Penalty for excessive drawdown
- **Discipline Bonus**: Weight 0.1 - Small bonus for good trading behavior

### 2. **Drawdown Calculation**
- High water mark tracking for maximum equity achieved
- Penalty triggered when drawdown exceeds 10% (configurable)
- Penalty scales with excess drawdown amount
- Drawdown calculated as: (high_water_mark - current_equity) / high_water_mark

### 3. **Discipline Metrics**
- **Holding Period Bonus**: Reward for holding positions at least 5 steps
- **Overtrading Penalty**: Penalty for more than 10 trades per 100 steps
- **Position Limit Bonus**: Small bonus for respecting position limits

### 4. **PnL Calculation**
- Realized PnL calculated when closing or changing positions
- Unrealized PnL tracked for current open positions
- PnL includes impact of transaction costs

## Implementation Decisions

### 1. **Gym Compatibility**
- Uses Gymnasium (updated OpenAI Gym) for future compatibility
- Follows standard Gym API: reset(), step(), render()
- Provides both terminated and truncated flags per latest Gym spec

### 2. **Data Requirements**
- Requires pre-computed features (assumes feature engineering is done)
- Data must have datetime index
- Minimum data length: lookback_window + max_steps rows
- NaN values should be removed before creating environment

### 3. **Episode Termination**
- Early termination on catastrophic loss (50% drawdown)
- Termination if data runs out
- Truncation at maximum steps

### 4. **Trade Execution**
- Trades executed at close price of current bar
- No partial fills - orders are always fully executed
- Transaction costs applied immediately
- Position changes are absolute, not relative

## Configuration Structure

The environment is highly configurable through YAML files:
- Episode parameters (max steps, lookback window)
- Trading parameters (capital, position limits)
- Cost structure (slippage, commission, spread)
- Action definitions and position mappings
- Reward weights and thresholds

## Future Considerations

1. **Market Impact**: Currently uses fixed slippage; could model dynamic impact
2. **Order Types**: Only market orders; could add limit orders
3. **Multi-Asset**: Currently single asset; could extend to portfolios
4. **Risk Metrics**: Could add Sharpe ratio, max drawdown to reward
5. **Continuous Actions**: Currently discrete; could support continuous position sizing