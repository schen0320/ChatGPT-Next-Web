# VNPy Trading Agent

A Python-based trading agent for algorithmic trading with support for data loading, feature engineering, and strategy implementation.

## Features

- Load historical OHLCV data from CSV and Parquet files
- Resample data to different timeframes
- Compute technical indicators (RSI, MACD, ATR, z-score)
- Extensible framework for trading strategies

## Installation

```bash
pip install -r requirements.txt
```

## Project Structure

```
vnpy-trading-agent/
├── src/
│   ├── data/
│   │   ├── loader.py          # Data loading and resampling
│   │   └── feature_engineer.py # Technical indicator computation
│   ├── strategies/            # Trading strategies
│   ├── trading/              # Trading execution
│   └── utils/                # Utility functions
├── tests/                    # Unit tests
├── config/                   # Configuration files
└── docs/                     # Documentation
```

## Usage

See individual module documentation for usage examples.

## Testing

Run tests with:
```bash
pytest tests/
```