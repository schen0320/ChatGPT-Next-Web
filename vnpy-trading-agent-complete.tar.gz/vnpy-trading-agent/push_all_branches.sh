#!/bin/bash

# Script to push all branches to GitHub

echo "Pushing all branches to GitHub..."

# Push master branch
echo "Pushing master branch..."
git push origin master

# Push task2-data-features branch
echo "Pushing task2-data-features branch..."
git push origin task2-data-features

# Push task3-env-reward branch
echo "Pushing task3-env-reward branch..."
git push origin task3-env-reward

# Push task4-risk-execution branch
echo "Pushing task4-risk-execution branch..."
git push origin task4-risk-execution

echo "All branches pushed successfully!"

# List all remote branches
echo -e "\nRemote branches:"
git branch -r

# Show current branch
echo -e "\nCurrent branch:"
git branch --show-current