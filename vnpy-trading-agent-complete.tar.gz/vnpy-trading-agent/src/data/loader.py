"""
Data loader module for loading and resampling OHLCV data from CSV and Parquet files.

This module provides functionality to:
- Load historical data from CSV and Parquet files
- Resample OHLCV data to different timeframes
- Validate data integrity

Assumptions:
- Data files have a datetime index
- OHLCV columns are present (open, high, low, close, volume)
- Data is sorted by datetime in ascending order
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Union, Optional, Dict
import yaml


class DataLoader:
    """Class for loading and processing OHLCV data."""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize DataLoader with configuration.
        
        Args:
            config_path: Path to configuration file. If None, uses default config.
        """
        self.config = self._load_config(config_path)
        self.column_mapping = self.config['data']['column_mapping']
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Load configuration from YAML file."""
        if config_path is None:
            config_path = Path(__file__).parent.parent.parent / 'config' / 'config.yaml'
        
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def load_csv(self, 
                 filepath: Union[str, Path], 
                 datetime_col: str = 'datetime',
                 parse_dates: bool = True) -> pd.DataFrame:
        """
        Load OHLCV data from CSV file.
        
        Args:
            filepath: Path to CSV file
            datetime_col: Name of datetime column
            parse_dates: Whether to parse dates
            
        Returns:
            DataFrame with datetime index and OHLCV columns
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If required columns are missing
        """
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"File not found: {filepath}")
        
        # Load data
        df = pd.read_csv(filepath, parse_dates=parse_dates)
        
        # Set datetime index if datetime column exists
        if datetime_col in df.columns:
            df[datetime_col] = pd.to_datetime(df[datetime_col])
            df.set_index(datetime_col, inplace=True)
        elif not isinstance(df.index, pd.DatetimeIndex):
            raise ValueError(f"No datetime column '{datetime_col}' found and index is not DatetimeIndex")
        
        # Validate required columns
        self._validate_ohlcv_columns(df)
        
        # Sort by index
        df.sort_index(inplace=True)
        
        return df
    
    def load_parquet(self, filepath: Union[str, Path]) -> pd.DataFrame:
        """
        Load OHLCV data from Parquet file.
        
        Args:
            filepath: Path to Parquet file
            
        Returns:
            DataFrame with datetime index and OHLCV columns
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If required columns are missing
        """
        filepath = Path(filepath)
        if not filepath.exists():
            raise FileNotFoundError(f"File not found: {filepath}")
        
        # Load data
        df = pd.read_parquet(filepath)
        
        # Ensure datetime index
        if not isinstance(df.index, pd.DatetimeIndex):
            # Try to find a datetime column
            datetime_cols = [col for col in df.columns if 'date' in col.lower() or 'time' in col.lower()]
            if datetime_cols:
                df[datetime_cols[0]] = pd.to_datetime(df[datetime_cols[0]])
                df.set_index(datetime_cols[0], inplace=True)
            else:
                raise ValueError("No datetime index or datetime column found")
        
        # Validate required columns
        self._validate_ohlcv_columns(df)
        
        # Sort by index
        df.sort_index(inplace=True)
        
        return df
    
    def _validate_ohlcv_columns(self, df: pd.DataFrame) -> None:
        """
        Validate that DataFrame contains required OHLCV columns.
        
        Args:
            df: DataFrame to validate
            
        Raises:
            ValueError: If required columns are missing
        """
        required_columns = ['open', 'high', 'low', 'close', 'volume']
        missing_columns = []
        
        for col in required_columns:
            mapped_col = self.column_mapping.get(col, col)
            if mapped_col not in df.columns:
                # Try case-insensitive search
                found = False
                for df_col in df.columns:
                    if df_col.lower() == mapped_col.lower():
                        found = True
                        break
                if not found:
                    missing_columns.append(mapped_col)
        
        if missing_columns:
            raise ValueError(f"Missing required OHLCV columns: {missing_columns}")
    
    def resample_ohlcv(self, 
                       df: pd.DataFrame, 
                       timeframe: str,
                       aggregation: Optional[Dict[str, str]] = None) -> pd.DataFrame:
        """
        Resample OHLCV data to specified timeframe.
        
        Args:
            df: DataFrame with OHLCV data
            timeframe: Target timeframe (e.g., '1H', '1D', '5min')
            aggregation: Custom aggregation rules. If None, uses OHLCV defaults.
            
        Returns:
            Resampled DataFrame
            
        Raises:
            ValueError: If timeframe is not supported
        """
        # Validate timeframe
        supported_timeframes = self.config['data']['supported_timeframes']
        if timeframe not in supported_timeframes:
            raise ValueError(f"Unsupported timeframe: {timeframe}. Supported: {supported_timeframes}")
        
        # Default OHLCV aggregation rules
        if aggregation is None:
            aggregation = {
                'open': 'first',
                'high': 'max',
                'low': 'min',
                'close': 'last',
                'volume': 'sum'
            }
        
        # Map column names
        mapped_aggregation = {}
        for key, value in aggregation.items():
            mapped_col = self.column_mapping.get(key, key)
            # Find the actual column name (case-insensitive)
            for col in df.columns:
                if col.lower() == mapped_col.lower():
                    mapped_aggregation[col] = value
                    break
        
        # Resample
        resampled = df.resample(timeframe).agg(mapped_aggregation)
        
        # Remove NaN rows (e.g., weekends for daily data)
        resampled.dropna(inplace=True)
        
        return resampled
    
    def load_and_resample(self,
                         filepath: Union[str, Path],
                         timeframe: Optional[str] = None,
                         file_format: Optional[str] = None) -> pd.DataFrame:
        """
        Load data from file and optionally resample to specified timeframe.
        
        Args:
            filepath: Path to data file
            timeframe: Target timeframe for resampling. If None, uses default from config.
            file_format: File format ('csv' or 'parquet'). If None, inferred from extension.
            
        Returns:
            Loaded and optionally resampled DataFrame
        """
        filepath = Path(filepath)
        
        # Infer file format if not specified
        if file_format is None:
            file_format = filepath.suffix.lower().replace('.', '')
        
        # Load data
        if file_format == 'csv':
            df = self.load_csv(filepath)
        elif file_format == 'parquet':
            df = self.load_parquet(filepath)
        else:
            raise ValueError(f"Unsupported file format: {file_format}")
        
        # Resample if timeframe specified
        if timeframe is None:
            timeframe = self.config['data']['default_timeframe']
            
        if timeframe:
            df = self.resample_ohlcv(df, timeframe)
        
        return df