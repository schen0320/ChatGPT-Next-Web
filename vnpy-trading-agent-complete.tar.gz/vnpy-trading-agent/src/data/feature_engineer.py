"""
Feature engineering module for computing technical indicators.

This module provides functionality to compute various technical indicators:
- RSI (Relative Strength Index)
- MACD (Moving Average Convergence Divergence)
- ATR (Average True Range)
- Z-score normalization

Assumptions:
- Input data has OHLCV columns
- Data is sorted by datetime index
- The 'ta' (Technical Analysis) library is installed
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, Union
import ta
import yaml
from pathlib import Path


class FeatureEngineer:
    """Class for computing technical indicators and features."""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize FeatureEngineer with configuration.
        
        Args:
            config_path: Path to configuration file. If None, uses default config.
        """
        self.config = self._load_config(config_path)
        self.indicator_config = self.config['indicators']
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Load configuration from YAML file."""
        if config_path is None:
            config_path = Path(__file__).parent.parent.parent / 'config' / 'config.yaml'
        
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def compute_rsi(self, 
                    df: pd.DataFrame, 
                    column: str = 'close',
                    period: Optional[int] = None) -> pd.Series:
        """
        Compute Relative Strength Index (RSI).
        
        RSI measures momentum - whether a stock is overbought or oversold.
        Values range from 0 to 100, with readings above 70 indicating overbought
        conditions and below 30 indicating oversold conditions.
        
        Args:
            df: DataFrame with OHLCV data
            column: Column to compute RSI on (default: 'close')
            period: Period for RSI calculation. If None, uses config default.
            
        Returns:
            Series with RSI values
        """
        if period is None:
            period = self.indicator_config['rsi']['period']
        
        # Find the column (case-insensitive)
        col_name = self._find_column(df, column)
        
        # Use ta library for RSI calculation
        rsi = ta.momentum.RSIIndicator(close=df[col_name], window=period)
        return rsi.rsi()
    
    def compute_macd(self, 
                     df: pd.DataFrame,
                     column: str = 'close',
                     fast_period: Optional[int] = None,
                     slow_period: Optional[int] = None,
                     signal_period: Optional[int] = None) -> pd.DataFrame:
        """
        Compute MACD (Moving Average Convergence Divergence).
        
        MACD is a trend-following momentum indicator that shows the relationship
        between two moving averages of prices.
        
        Args:
            df: DataFrame with OHLCV data
            column: Column to compute MACD on (default: 'close')
            fast_period: Fast EMA period. If None, uses config default.
            slow_period: Slow EMA period. If None, uses config default.
            signal_period: Signal line EMA period. If None, uses config default.
            
        Returns:
            DataFrame with columns: macd, macd_signal, macd_diff
        """
        if fast_period is None:
            fast_period = self.indicator_config['macd']['fast_period']
        if slow_period is None:
            slow_period = self.indicator_config['macd']['slow_period']
        if signal_period is None:
            signal_period = self.indicator_config['macd']['signal_period']
        
        # Find the column (case-insensitive)
        col_name = self._find_column(df, column)
        
        # Use ta library for MACD calculation
        macd = ta.trend.MACD(
            close=df[col_name],
            window_slow=slow_period,
            window_fast=fast_period,
            window_sign=signal_period
        )
        
        result = pd.DataFrame(index=df.index)
        result['macd'] = macd.macd()
        result['macd_signal'] = macd.macd_signal()
        result['macd_diff'] = macd.macd_diff()
        
        return result
    
    def compute_atr(self,
                    df: pd.DataFrame,
                    period: Optional[int] = None) -> pd.Series:
        """
        Compute Average True Range (ATR).
        
        ATR is a volatility indicator that measures the average range of price
        movement over a specified period.
        
        Args:
            df: DataFrame with OHLCV data (requires high, low, close columns)
            period: Period for ATR calculation. If None, uses config default.
            
        Returns:
            Series with ATR values
        """
        if period is None:
            period = self.indicator_config['atr']['period']
        
        # Find required columns (case-insensitive)
        high_col = self._find_column(df, 'high')
        low_col = self._find_column(df, 'low')
        close_col = self._find_column(df, 'close')
        
        # Use ta library for ATR calculation
        atr = ta.volatility.AverageTrueRange(
            high=df[high_col],
            low=df[low_col],
            close=df[close_col],
            window=period
        )
        
        return atr.average_true_range()
    
    def compute_zscore(self,
                       df: pd.DataFrame,
                       column: str = 'close',
                       period: Optional[int] = None) -> pd.Series:
        """
        Compute z-score normalization.
        
        Z-score indicates how many standard deviations a value is from the mean.
        Useful for identifying extreme values and mean reversion opportunities.
        
        Args:
            df: DataFrame with data
            column: Column to compute z-score on
            period: Rolling window period. If None, uses config default.
            
        Returns:
            Series with z-score values
        """
        if period is None:
            period = self.indicator_config['zscore']['period']
        
        # Find the column (case-insensitive)
        col_name = self._find_column(df, column)
        
        # Calculate rolling mean and standard deviation
        rolling_mean = df[col_name].rolling(window=period).mean()
        rolling_std = df[col_name].rolling(window=period).std()
        
        # Calculate z-score
        zscore = (df[col_name] - rolling_mean) / rolling_std
        
        return zscore
    
    def compute_all_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Compute all configured indicators and add them to the DataFrame.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with original data and all computed indicators
        """
        result = df.copy()
        
        # Compute RSI
        result['rsi'] = self.compute_rsi(df)
        
        # Compute MACD
        macd_df = self.compute_macd(df)
        result['macd'] = macd_df['macd']
        result['macd_signal'] = macd_df['macd_signal']
        result['macd_diff'] = macd_df['macd_diff']
        
        # Compute ATR
        result['atr'] = self.compute_atr(df)
        
        # Compute z-score
        result['zscore'] = self.compute_zscore(df)
        
        return result
    
    def _find_column(self, df: pd.DataFrame, column: str) -> str:
        """
        Find column name in DataFrame (case-insensitive).
        
        Args:
            df: DataFrame to search in
            column: Column name to find
            
        Returns:
            Actual column name in DataFrame
            
        Raises:
            ValueError: If column not found
        """
        for col in df.columns:
            if col.lower() == column.lower():
                return col
        
        raise ValueError(f"Column '{column}' not found in DataFrame")
    
    def add_price_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Add additional price-based features.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            DataFrame with additional features
        """
        result = df.copy()
        
        # Find columns
        open_col = self._find_column(df, 'open')
        high_col = self._find_column(df, 'high')
        low_col = self._find_column(df, 'low')
        close_col = self._find_column(df, 'close')
        volume_col = self._find_column(df, 'volume')
        
        # Price range
        result['price_range'] = df[high_col] - df[low_col]
        
        # Price position within daily range
        result['price_position'] = (df[close_col] - df[low_col]) / (df[high_col] - df[low_col])
        
        # Returns
        result['returns'] = df[close_col].pct_change()
        
        # Log returns
        result['log_returns'] = np.log(df[close_col] / df[close_col].shift(1))
        
        # Volume weighted average price (VWAP) - simple version
        result['vwap'] = (df[volume_col] * (df[high_col] + df[low_col] + df[close_col]) / 3).cumsum() / df[volume_col].cumsum()
        
        # Bollinger Bands
        bb = ta.volatility.BollingerBands(close=df[close_col])
        result['bb_upper'] = bb.bollinger_hband()
        result['bb_middle'] = bb.bollinger_mavg()
        result['bb_lower'] = bb.bollinger_lband()
        result['bb_width'] = bb.bollinger_wband()
        result['bb_percent'] = bb.bollinger_pband()
        
        return result