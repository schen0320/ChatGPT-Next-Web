"""
Reward calculation module for the trading environment.

This module implements various reward functions that consider:
- Profit and Loss (PnL)
- Transaction costs (slippage, commission, spread)
- Drawdown penalties
- Discipline bonuses (holding periods, position limits)
"""

import numpy as np
from typing import Dict, Optional, List, Tuple
import yaml
from pathlib import Path


class RewardCalculator:
    """Calculate rewards for trading actions based on various factors."""
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize RewardCalculator with configuration.
        
        Args:
            config_path: Path to configuration file. If None, uses default config.
        """
        self.config = self._load_config(config_path)
        self.reward_config = self.config['reward']
        self.env_config = self.config['environment']
        
        # Track metrics for discipline bonuses
        self.trade_history: List[int] = []  # Track trade timestamps
        self.position_history: List[float] = []  # Track position sizes
        self.high_water_mark: float = 0.0  # For drawdown calculation
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Load configuration from YAML file."""
        if config_path is None:
            config_path = Path(__file__).parent.parent.parent / 'configs' / 'env.yaml'
        
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def calculate_reward(self,
                        pnl: float,
                        transaction_cost: float,
                        current_equity: float,
                        position: float,
                        step: int,
                        action_taken: bool) -> Tuple[float, Dict[str, float]]:
        """
        Calculate total reward based on multiple factors.
        
        Args:
            pnl: Profit/loss from the action
            transaction_cost: Cost of the transaction (0 if no trade)
            current_equity: Current account equity
            position: Current position size
            step: Current time step
            action_taken: Whether a trade was executed
            
        Returns:
            Tuple of (total_reward, reward_components)
        """
        components = {}
        
        # 1. PnL component
        pnl_reward = pnl * self.reward_config['weights']['pnl']
        components['pnl'] = pnl_reward
        
        # 2. Transaction cost penalty
        cost_penalty = transaction_cost * self.reward_config['weights']['transaction_cost']
        components['transaction_cost'] = cost_penalty
        
        # 3. Drawdown penalty
        drawdown_penalty = self._calculate_drawdown_penalty(current_equity)
        components['drawdown'] = drawdown_penalty
        
        # 4. Discipline bonuses
        discipline_bonus = self._calculate_discipline_bonus(
            position, step, action_taken
        )
        components['discipline'] = discipline_bonus
        
        # Update tracking metrics
        if action_taken:
            self.trade_history.append(step)
        self.position_history.append(position)
        
        # Calculate total reward
        total_reward = sum(components.values())
        
        return total_reward, components
    
    def _calculate_drawdown_penalty(self, current_equity: float) -> float:
        """
        Calculate penalty based on drawdown from high water mark.
        
        Args:
            current_equity: Current account equity
            
        Returns:
            Drawdown penalty (negative value)
        """
        # Update high water mark
        self.high_water_mark = max(self.high_water_mark, current_equity)
        
        # Calculate drawdown
        if self.high_water_mark > 0:
            drawdown = (self.high_water_mark - current_equity) / self.high_water_mark
        else:
            drawdown = 0.0
        
        # Apply penalty if drawdown exceeds threshold
        max_allowed = self.reward_config['drawdown']['max_allowed']
        if drawdown > max_allowed:
            excess_drawdown = drawdown - max_allowed
            penalty_scale = self.reward_config['drawdown']['penalty_scale']
            penalty = excess_drawdown * penalty_scale * self.reward_config['weights']['drawdown_penalty']
            return penalty
        
        return 0.0
    
    def _calculate_discipline_bonus(self,
                                   position: float,
                                   step: int,
                                   action_taken: bool) -> float:
        """
        Calculate bonus for disciplined trading behavior.
        
        Args:
            position: Current position size
            step: Current time step
            action_taken: Whether a trade was executed
            
        Returns:
            Discipline bonus (positive value)
        """
        bonus = 0.0
        discipline_config = self.reward_config['discipline']
        
        # 1. Bonus for holding positions for minimum period
        if len(self.position_history) >= discipline_config['min_hold_periods']:
            recent_positions = self.position_history[-discipline_config['min_hold_periods']:]
            if all(p == recent_positions[0] and p != 0 for p in recent_positions):
                bonus += discipline_config['position_limit_bonus']
        
        # 2. Penalty for overtrading
        if step > 100:  # Only check after initial period
            recent_trades = [t for t in self.trade_history if t > step - 100]
            trade_frequency = len(recent_trades)
            if trade_frequency > discipline_config['overtrading_threshold']:
                # Apply penalty for overtrading
                excess_trades = trade_frequency - discipline_config['overtrading_threshold']
                bonus -= excess_trades * 0.01  # Small penalty per excess trade
        
        # 3. Bonus for respecting position limits
        max_position = self.env_config['trading']['max_position_size']
        if abs(position) <= max_position:
            bonus += discipline_config['position_limit_bonus'] * 0.5
        
        return bonus * self.reward_config['weights']['discipline_bonus']
    
    def calculate_transaction_cost(self,
                                  trade_value: float,
                                  trade_size: float) -> float:
        """
        Calculate total transaction cost including slippage, commission, and spread.
        
        Args:
            trade_value: Total value of the trade
            trade_size: Size of the trade (can be negative for sells)
            
        Returns:
            Total transaction cost (positive value)
        """
        if trade_size == 0:
            return 0.0
        
        costs_config = self.env_config['costs']
        
        # Slippage cost (proportional to trade size)
        slippage_cost = abs(trade_value) * costs_config['slippage']
        
        # Commission cost
        commission_cost = abs(trade_value) * costs_config['commission']
        
        # Spread cost (half spread paid on entry and exit)
        spread_cost = abs(trade_value) * costs_config['spread'] * 0.5
        
        total_cost = slippage_cost + commission_cost + spread_cost
        
        return total_cost
    
    def reset(self):
        """Reset internal state for new episode."""
        self.trade_history.clear()
        self.position_history.clear()
        self.high_water_mark = 0.0
    
    def get_episode_stats(self) -> Dict[str, float]:
        """
        Get statistics for the current episode.
        
        Returns:
            Dictionary with episode statistics
        """
        stats = {
            'total_trades': len(self.trade_history),
            'high_water_mark': self.high_water_mark,
            'final_drawdown': 0.0
        }
        
        if self.high_water_mark > 0 and self.position_history:
            # Estimate final drawdown (would need current equity for exact value)
            stats['avg_position'] = np.mean(np.abs(self.position_history))
            
        if len(self.trade_history) > 1:
            # Calculate average holding period
            holding_periods = []
            for i in range(1, len(self.trade_history)):
                holding_periods.append(self.trade_history[i] - self.trade_history[i-1])
            stats['avg_holding_period'] = np.mean(holding_periods)
        
        return stats