"""
Gym-style trading environment for reinforcement learning.

This module implements a trading environment compatible with OpenAI Gym/Gymnasium
that supports:
- 7 discrete actions (strong sell to strong buy)
- Stacked feature observations with lookback window
- Realistic trading mechanics (slippage, fees, position limits)
- Episode termination conditions
"""

import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd
from typing import Dict, Tuple, Optional, Any, List
import yaml
from pathlib import Path

from ..data.loader import DataLoader
from ..data.feature_engineer import FeatureEngineer
from .reward import RewardCalculator


class TradingEnvironment(gym.Env):
    """Gym-compatible trading environment."""
    
    metadata = {"render_modes": ["human"]}
    
    def __init__(self,
                 data: pd.DataFrame,
                 config_path: Optional[str] = None,
                 render_mode: Optional[str] = None):
        """
        Initialize trading environment.
        
        Args:
            data: DataFrame with OHLCV data and features
            config_path: Path to configuration file
            render_mode: Rendering mode (e.g., "human")
        """
        super().__init__()
        
        self.data = data
        self.render_mode = render_mode
        
        # Load configuration
        self.config = self._load_config(config_path)
        self.env_config = self.config['environment']
        
        # Initialize components
        self.reward_calculator = RewardCalculator(config_path)
        
        # Episode parameters
        self.max_steps = self.env_config['episode']['max_steps']
        self.lookback_window = self.env_config['episode']['lookback_window']
        
        # Trading parameters
        self.initial_capital = self.env_config['trading']['initial_capital']
        self.max_position_size = self.env_config['trading']['max_position_size']
        self.min_trade_size = self.env_config['trading']['min_trade_size']
        
        # Define action and observation spaces
        self.action_space = spaces.Discrete(7)  # 7 discrete actions
        
        # Calculate observation space dimensions
        feature_columns = self.env_config['observation']['features']
        state_features = self.env_config['observation']['state_features']
        n_features = len(feature_columns) + len(state_features)
        
        # Observation: lookback_window x n_features
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(self.lookback_window, n_features),
            dtype=np.float32
        )
        
        # Action mapping
        self.action_positions = self.env_config['action_position_sizes']
        self.action_names = self.env_config['actions']
        
        # Feature configuration
        self.feature_columns = feature_columns
        self.state_features = state_features
        
        # Validate data has required features
        self._validate_data()
        
        # Episode state (will be initialized in reset)
        self.current_step = 0
        self.start_idx = 0
        self.position = 0.0
        self.cash = self.initial_capital
        self.equity = self.initial_capital
        self.entry_price = 0.0
        self.trades = []
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Load configuration from YAML file."""
        if config_path is None:
            config_path = Path(__file__).parent.parent.parent / 'configs' / 'env.yaml'
        
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    
    def _validate_data(self):
        """Validate that data contains all required features."""
        missing_features = []
        for feature in self.feature_columns:
            if feature not in self.data.columns:
                missing_features.append(feature)
        
        if missing_features:
            raise ValueError(f"Data missing required features: {missing_features}")
        
        # Check data has enough rows
        min_rows = self.lookback_window + self.max_steps
        if len(self.data) < min_rows:
            raise ValueError(f"Data has {len(self.data)} rows, need at least {min_rows}")
    
    def reset(self, seed: Optional[int] = None, options: Optional[Dict] = None) -> Tuple[np.ndarray, Dict]:
        """
        Reset environment to initial state.
        
        Args:
            seed: Random seed
            options: Additional options
            
        Returns:
            Tuple of (initial_observation, info)
        """
        super().reset(seed=seed)
        
        # Reset reward calculator
        self.reward_calculator.reset()
        
        # Sample random starting point
        max_start = len(self.data) - self.lookback_window - self.max_steps
        self.start_idx = self.np_random.integers(0, max_start)
        
        # Reset episode state
        self.current_step = 0
        self.position = 0.0
        self.cash = self.initial_capital
        self.equity = self.initial_capital
        self.entry_price = 0.0
        self.trades = []
        
        # Get initial observation
        obs = self._get_observation()
        info = self._get_info()
        
        return obs, info
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """
        Execute one step in the environment.
        
        Args:
            action: Action to take (0-6)
            
        Returns:
            Tuple of (observation, reward, terminated, truncated, info)
        """
        # Get current price
        current_idx = self.start_idx + self.current_step + self.lookback_window
        current_price = self.data.iloc[current_idx]['close']
        
        # Execute action
        action_name = self.action_names[action]
        target_position = self.action_positions[action_name]
        
        # Calculate trade details
        position_change = target_position - self.position
        trade_executed = abs(position_change) >= self.min_trade_size
        
        pnl = 0.0
        transaction_cost = 0.0
        
        if trade_executed:
            # Calculate trade value
            trade_value = abs(position_change) * current_price * self.initial_capital
            
            # Calculate transaction costs
            transaction_cost = self.reward_calculator.calculate_transaction_cost(
                trade_value, position_change
            )
            
            # Update position and cash
            if self.position != 0:
                # Close existing position (realize PnL)
                pnl = self.position * (current_price - self.entry_price) * self.initial_capital
                self.cash += self.position * current_price * self.initial_capital
            
            # Open new position
            self.position = target_position
            if target_position != 0:
                self.entry_price = current_price
                self.cash -= target_position * current_price * self.initial_capital
            
            # Deduct transaction costs
            self.cash -= transaction_cost
            
            # Record trade
            self.trades.append({
                'step': self.current_step,
                'action': action_name,
                'price': current_price,
                'position': target_position,
                'pnl': pnl,
                'cost': transaction_cost
            })
        
        # Calculate current equity
        unrealized_pnl = 0.0
        if self.position != 0:
            unrealized_pnl = self.position * (current_price - self.entry_price) * self.initial_capital
        
        self.equity = self.cash + abs(self.position) * current_price * self.initial_capital + unrealized_pnl
        
        # Calculate reward
        reward, reward_components = self.reward_calculator.calculate_reward(
            pnl=pnl,
            transaction_cost=transaction_cost,
            current_equity=self.equity,
            position=self.position,
            step=self.current_step,
            action_taken=trade_executed
        )
        
        # Check termination conditions before moving to next step
        terminated = self._is_terminated()
        
        # Move to next step
        self.current_step += 1
        
        truncated = self.current_step >= self.max_steps
        
        # Get next observation
        obs = self._get_observation()
        
        # Compile info
        info = self._get_info()
        info['reward_components'] = reward_components
        info['trade_executed'] = trade_executed
        
        return obs, reward, terminated, truncated, info
    
    def _get_observation(self) -> np.ndarray:
        """
        Get current observation (stacked features).
        
        Returns:
            Observation array of shape (lookback_window, n_features)
        """
        current_idx = self.start_idx + self.current_step + self.lookback_window
        start_idx = current_idx - self.lookback_window
        
        # Get historical features
        historical_data = self.data.iloc[start_idx:current_idx][self.feature_columns].values
        
        # Add state features for each timestep
        state_values = []
        for i in range(self.lookback_window):
            state_row = [
                self.position,  # Current position
                0.0 if self.position == 0 else (self.data.iloc[start_idx + i]['close'] - self.entry_price) * self.position * self.initial_capital,  # Unrealized PnL
                self.cash / self.initial_capital  # Normalized cash
            ]
            state_values.append(state_row)
        
        state_array = np.array(state_values)
        
        # Combine features
        observation = np.hstack([historical_data, state_array]).astype(np.float32)
        
        return observation
    
    def _is_terminated(self) -> bool:
        """
        Check if episode should terminate early.
        
        Returns:
            True if episode should terminate
        """
        # Terminate if equity drops below 50% of initial capital
        if self.equity < self.initial_capital * 0.5:
            return True
        
        # Terminate if we've exhausted available data
        current_idx = self.start_idx + self.current_step + self.lookback_window
        if current_idx >= len(self.data) - 1:
            return True
        
        return False
    
    def _get_info(self) -> Dict[str, Any]:
        """
        Get current environment info.
        
        Returns:
            Dictionary with environment state information
        """
        return {
            'step': self.current_step,
            'position': self.position,
            'cash': self.cash,
            'equity': self.equity,
            'trades': len(self.trades),
            'current_price': self.data.iloc[self.start_idx + self.current_step + self.lookback_window - 1]['close']
        }
    
    def render(self):
        """Render the environment (human mode)."""
        if self.render_mode == "human":
            info = self._get_info()
            print(f"Step: {info['step']}, Position: {info['position']:.2f}, "
                  f"Equity: ${info['equity']:.2f}, Price: ${info['current_price']:.2f}")
    
    def close(self):
        """Clean up environment resources."""
        pass
    
    def get_episode_summary(self) -> Dict[str, Any]:
        """
        Get summary statistics for the completed episode.
        
        Returns:
            Dictionary with episode statistics
        """
        summary = {
            'total_steps': self.current_step,
            'total_trades': len(self.trades),
            'final_equity': self.equity,
            'total_return': (self.equity - self.initial_capital) / self.initial_capital,
            'reward_stats': self.reward_calculator.get_episode_stats()
        }
        
        if self.trades:
            # Calculate trade statistics
            pnls = [t['pnl'] for t in self.trades]
            costs = [t['cost'] for t in self.trades]
            
            summary['total_pnl'] = sum(pnls)
            summary['total_costs'] = sum(costs)
            summary['avg_pnl_per_trade'] = np.mean(pnls) if pnls else 0
            summary['win_rate'] = sum(1 for p in pnls if p > 0) / len(pnls) if pnls else 0
            
        return summary


def create_trading_env(data_path: str,
                      config_path: Optional[str] = None,
                      timeframe: str = '1h') -> TradingEnvironment:
    """
    Create a trading environment with data preprocessing.
    
    Args:
        data_path: Path to data file (CSV or Parquet)
        config_path: Path to configuration file
        timeframe: Timeframe for data resampling
        
    Returns:
        Initialized trading environment
    """
    # Load and prepare data
    data_loader = DataLoader()
    feature_engineer = FeatureEngineer()
    
    # Load data
    data = data_loader.load_and_resample(data_path, timeframe)
    
    # Add all features
    data = feature_engineer.compute_all_indicators(data)
    data = feature_engineer.add_price_features(data)
    
    # Remove NaN values
    data = data.dropna()
    
    # Create environment
    env = TradingEnvironment(data, config_path)
    
    return env